﻿param([switch]$SetupOnly)

$ErrorActionPreference = 'Stop'
$app = Join-Path $PSScriptRoot 'App\Yakupova Miracle.exe'
try {
    [xml]$config = Get-Content -Raw -LiteralPath "$app.config"
    $entry = $config.configuration.connectionStrings.add |
        Where-Object { $_.name -eq 'YakupovaMiracleEntities' }
    $entity = New-Object System.Data.Common.DbConnectionStringBuilder
    $entity.set_ConnectionString([string]$entry.connectionString)
    $settings = [System.Data.SqlClient.SqlConnectionStringBuilder]::new([string]$entity['provider connection string'])
    $database = $settings['Initial Catalog']
    $settings['Initial Catalog'] = 'master'
    $connection = [System.Data.SqlClient.SqlConnection]::new($settings.ConnectionString)
    try {
        $connection.Open()
        $command = $connection.CreateCommand()
        $command.CommandTimeout = 60
        $command.CommandText = "DECLARE @result int; EXEC @result = sys.sp_getapplock @Resource = @lock, @LockMode = 'Exclusive', @LockOwner = 'Session', @LockTimeout = 15000; SELECT @result;"
        [void]$command.Parameters.AddWithValue('@lock', "YakupovaMiracle setup: $database")
        if ($command.ExecuteScalar() -lt 0) { throw 'Не удалось получить блокировку настройки базы.' }
        $command.Parameters.Clear()
        $command.CommandText = 'SELECT DB_ID(@name);'
        [void]$command.Parameters.AddWithValue('@name', $database)
        $exists = $command.ExecuteScalar() -isnot [DBNull]
        $command.Parameters.Clear()
        if (!$exists) {
            if ($database -ne 'YakupovaMiracleDemo') {
                throw "База $database не найдена. Разверните свою копию базы в SSMS."
            }
            $sql = [IO.File]::ReadAllText((Join-Path $PSScriptRoot 'YakupovaMiracleDemo.sql'))
            $created = $false
            $transaction = $null
            try {
                foreach ($batch in ($sql -split '(?im)^GO[ \t]*\r?$')) {
                    $batch = $batch.Trim()
                    if (!$batch -or $batch -eq 'USE [master]') { continue }
                    if ($batch -eq 'USE [YakupovaMiracleDemo]') {
                        $connection.ChangeDatabase($database)
                        $transaction = $connection.BeginTransaction()
                        continue
                    }
                    $command.Transaction = $transaction
                    $command.CommandText = $batch
                    [void]$command.ExecuteNonQuery()
                    if ($batch -match '^CREATE DATABASE ') { $created = $true }
                }
                if ($null -eq $transaction) { throw 'SQL-скрипт не переключился на демобазу.' }
                $transaction.Commit()
            } catch {
                if ($transaction -and $transaction.Connection) { $transaction.Rollback() }
                if ($created) {
                    $command.Transaction = $null
                    $connection.ChangeDatabase('master')
                    $command.CommandText = 'DROP DATABASE [YakupovaMiracleDemo];'
                    [void]$command.ExecuteNonQuery()
                }
                throw
            } finally {
                if ($transaction) { $transaction.Dispose() }
            }
        }
    } finally {
        $connection.Dispose()
    }
    if (!$SetupOnly) { Start-Process -FilePath $app -WorkingDirectory (Split-Path $app) -WindowStyle Normal }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host 'Проверьте, что установлен SQL Server Express LocalDB. Подробности есть в README.md.'
    exit 1
}
