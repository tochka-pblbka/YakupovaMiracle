﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Yakupova_Miracle
{
    public partial class Productpage : Page
    {
        private readonly List<OrderItem> selectedOrderProducts = new List<OrderItem>();
        private readonly Client currentUser;
        private bool isReady;

        public Productpage(Client user)
        {
            currentUser = user;
            InitializeComponent();
            FIOTB.Text = user == null ? "Гость" : user.FIO;
            RoleTB.Text = user == null ? "Гость" : user.UserRole.RoleName;
            OrdersBtn.Visibility = user != null && (user.RoleID == 1 || user.RoleID == 2) ? Visibility.Visible : Visibility.Collapsed;
            AnalyticsBtn.Visibility = user != null && user.RoleID == 1 ? Visibility.Visible : Visibility.Collapsed;
            FilterPanel.Visibility = user == null ? Visibility.Collapsed : Visibility.Visible;
            if (user != null)
            {
                var categories = YakupovaMiracleEntities.GetContext().Category.ToList();
                categories.Insert(0, new Category { CategoryID = 0, CategoryName = "Все категории" });
                ComboType.ItemsSource = categories;
                ComboType.DisplayMemberPath = "CategoryName";
                ComboType.SelectedIndex = 0;
            }
            isReady = true;
            UpdateServices();
        }

        private void TBoxSearch_TextChanged(object sender, TextChangedEventArgs e) { UpdateServices(); }
        private void ComboType_SelectionChanged(object sender, SelectionChangedEventArgs e) { UpdateServices(); }
        private void RButtonUp_Checked(object sender, RoutedEventArgs e) { UpdateServices(); }
        private void RButtonDown_Checked(object sender, RoutedEventArgs e) { UpdateServices(); }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try { UpdateServices(); }
            catch (Exception ex) { MessageBox.Show("Не удалось обновить каталог: " + ex.GetBaseException().Message); }
        }

        private void UpdateServices()
        {


            if (!isReady) return;
            List<Product> currentServices;
            using (var context = new YakupovaMiracleEntities())
                currentServices = context.Product.AsNoTracking()
                    .Include(p => p.Category).Include(p => p.Manufacture)
                    .Include(p => p.CommodityPosition).ToList();
            int totalCount = currentServices.Count;
            if (currentUser != null)
            {
                var category = ComboType.SelectedItem as Category;
                if (category != null && category.CategoryID != 0)
                    currentServices = currentServices.Where(p => p.CategoryID == category.CategoryID).ToList();
                currentServices = currentServices.Where(p => p.ProductName.ToLower().Contains(TBoxSearch.Text.Trim().ToLower())).ToList();
                if (RButtonDown.IsChecked == true) currentServices = currentServices.OrderByDescending(p => p.Price).ToList();
                if (RButtonUp.IsChecked == true) currentServices = currentServices.OrderBy(p => p.Price).ToList();
            }
            TBlockRecordCount.Text = $"Записей: {currentServices.Count} из {totalCount}";
            ProductListView.ItemsSource = currentServices.ToList();
        }

        private void ProductListView_Click(object sender, MouseButtonEventArgs e)
        {
            var source = e.OriginalSource as DependencyObject;
            var item = source == null ? null : ItemsControl.ContainerFromElement(ProductListView, source) as ListViewItem;
            if (item != null) OpenProduct(item.DataContext as Product);
        }

        private void ProductListView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key != Key.Enter || currentUser == null) return;
            e.Handled = true;
            OpenProduct(ProductListView.SelectedItem as Product);
        }

        private void OpenProduct(Product selected)
        {
            if (currentUser == null || selected == null) return;
            try
            {
                Product product;
                using (var context = new YakupovaMiracleEntities())
                    product = context.Product.AsNoTracking().Include(p => p.Category).Include(p => p.Manufacture)
                        .Include(p => p.CommodityPosition).SingleOrDefault(p => p.ProductID == selected.ProductID);
                if (product == null)
                {
                    MessageBox.Show("Товар больше не доступен.");
                    UpdateServices();
                    return;
                }

                var details = new ProductDetailsWindow(product, selectedOrderProducts) { Owner = Window.GetWindow(this) };
                if (details.ShowDialog() != true) return;

                var added = details.SelectedPosition;
                var existing = selectedOrderProducts.FirstOrDefault(p => p.CommodityPositionID == added.CommodityPositionID);
                if (existing == null) selectedOrderProducts.Add(added);
                else
                {
                    existing.Quantity += added.Quantity;
                    existing.PriceAtOrderTime = added.PriceAtOrderTime;
                }
                UpdateDraftControls();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось открыть карточку товара: " + ex.GetBaseException().Message);
            }
        }

        private void OrderBTn_Click(object sender, RoutedEventArgs e)
        {
            if (currentUser == null || selectedOrderProducts.Count == 0) return;
            try
            {
                var orderWindow = new OrderWindow(selectedOrderProducts, currentUser, fromCatalog: true)
                    { Owner = Window.GetWindow(this) };
                if (orderWindow.ShowDialog() != true) return;
                selectedOrderProducts.Clear();
                UpdateDraftControls();
                UpdateServices();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось обновить данные заказа: " + ex.GetBaseException().Message);
            }
        }

        private void CancelDraftBtn_Click(object sender, RoutedEventArgs e)
        {
            selectedOrderProducts.Clear();
            UpdateDraftControls();
        }

        private void UpdateDraftControls()
        {
            var visibility = selectedOrderProducts.Count == 0 ? Visibility.Collapsed : Visibility.Visible;
            OrderBTn.Visibility = visibility;
            CancelDraftBtn.Visibility = visibility;
            OrderBTn.Content = $"Просмотреть заказ ({selectedOrderProducts.Sum(p => p.Quantity)})";
        }


        private void OrdersBtn_Click(object sender, RoutedEventArgs e)
        {
            Manager.MainFrame.Navigate(new OrdersPage(currentUser));
        }

        private void AnalyticsBtn_Click(object sender, RoutedEventArgs e)
        {
            if (currentUser != null && currentUser.RoleID == 1)
                Manager.MainFrame.Navigate(new AnalyticsPage(currentUser));
        }
    }
}
