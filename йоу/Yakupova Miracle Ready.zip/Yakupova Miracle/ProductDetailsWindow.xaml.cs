﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Yakupova_Miracle
{
    public partial class ProductDetailsWindow : Window
    {
        private readonly List<OrderItem> draft;

        public OrderItem SelectedPosition { get; private set; }

        public ProductDetailsWindow(Product product, List<OrderItem> draft)
        {
            this.draft = draft;
            InitializeComponent();
            DataContext = product;
            SizeCombo.ItemsSource = product.AvailablePositions.Where(p => AvailableQuantity(p) > 0).ToList();
            SizeCombo.SelectedIndex = 0;
            UpdateAvailability();
        }

        private int AvailableQuantity(CommodityPosition position)
        {
            return position.QuantityInStock - draft
                .Where(p => p.CommodityPositionID == position.CommodityPositionID)
                .Sum(p => p.Quantity);
        }

        private void SizeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateAvailability();
        }

        private void UpdateAvailability()
        {
            var position = SizeCombo.SelectedItem as CommodityPosition;
            AvailableText.Text = position == null ? "Нет доступных размеров" : $"Доступно пар: {AvailableQuantity(position)}";
            QuantityBox.IsEnabled = position != null;
            AddBtn.IsEnabled = position != null;
            ErrorText.Text = "";
        }

        private void AddBtn_Click(object sender, RoutedEventArgs e)
        {
            var position = SizeCombo.SelectedItem as CommodityPosition;
            if (position == null) return;
            if (!int.TryParse(QuantityBox.Text, out int quantity) || quantity < 1 || quantity > AvailableQuantity(position))
            {
                ErrorText.Text = $"Введите целое количество от 1 до {AvailableQuantity(position)}.";
                return;
            }

            SelectedPosition = new OrderItem
            {
                CommodityPositionID = position.CommodityPositionID,
                CommodityPosition = position,
                Quantity = quantity,
                PriceAtOrderTime = ((Product)DataContext).Price
            };
            DialogResult = true;
        }
    }
}
